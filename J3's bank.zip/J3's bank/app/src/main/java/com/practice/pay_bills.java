package com.practice;

import android.app.*;
import android.os.*;

public class pay_bills extends Activity
{
		@Override
		protected void onCreate(Bundle savedInstanceState) {
				super.onCreate(savedInstanceState);
				setContentView(R.layout.paybills);
	
}
}
