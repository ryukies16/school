package com.practice;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.google.firebase.database.*;
import java.util.*;

public class maynilad extends Activity
{
		FirebaseDatabase maynilad = FirebaseDatabase.getInstance();
		DatabaseReference maynilads= maynilad.getReference().child("Maynilad Client");
		
	
			
				EditText macc,mname,mmount,mmail;
				Button mbtn;

		@Override
		protected void onCreate(Bundle savedInstanceState) {
				super.onCreate(savedInstanceState);
				setContentView(R.layout.maynilad);

				mmail=findViewById(R.id.mnilademail)                                                       ;
				macc=findViewById(R.id.mayniladAcc);
				mname=findViewById(R.id.mniladaccname);
				mmount=findViewById(R.id.mniladamount);
				mbtn=findViewById(R.id.mniladbtn);










				mbtn.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									String maccount= macc.getText().toString();
									String mnames=mname.getText().toString();
									String amount=mmount.getText().toString();
									String memail =mmail.getText().toString();

									Intent intent = new Intent(maynilad.this,nmaynilad.class);
									intent.putExtra("key1",maccount);
									intent.putExtra("key2",mnames);
									intent.putExtra("key3",amount);
									intent.putExtra("key4",memail);
									startActivity(intent);


									HashMap<String,String> mayclient = new HashMap<>();
									mayclient.put("Account Number",maccount);
								    mayclient.put("Account Name",mnames);
								    mayclient.put("Amount",amount);
								    mayclient.put("Email",memail);

									maynilads.setValue(mayclient);
									
									
								}


						});
						}
						}
