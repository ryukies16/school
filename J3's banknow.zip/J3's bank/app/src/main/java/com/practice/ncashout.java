package com.practice;

import android.app.*;
import android.os.*;
import android.widget.*;
import com.google.firebase.database.*;
import android.view.*;
import android.content.*;
import android.preference.*;
import android.view.View.*;
import java.util.*;

public class ncashout  extends Activity
	{
		String pnumber;
		FirebaseDatabase send = FirebaseDatabase.getInstance();
		DatabaseReference sending= send.getReference().child("Sender");
		
		Button btn;
		EditText num,amount,message;
		


		@Override
		protected void onCreate(Bundle savedInstanceState) {
				super.onCreate(savedInstanceState);
				setContentView(R.layout.ncashout);
				num =findViewById(R.id.sendnum);
				amount =findViewById(R.id.sendamount)                                           ;
				message=findViewById(R.id.sendmess);
				btn=findViewById(R.id.sendbtn);
				
				
				
				btn.setOnClickListener(new OnClickListener(){

					@Override
							public void onClick(View p1)
								{
									String pamount =amount.getText().toString();
									pnumber =num.getText().toString();
						            Intent intent =new Intent(ncashout.this,nncashout.class);
						intent.putExtra("key1",pnumber);
									intent.putExtra("key2",pamount);
							
									startActivity(intent);
									
									HashMap<String,String> sender=new HashMap<>();
									sender.put("phonenumber",pnumber);
									sender.put("amount",pamount);
									sending.setValue(sender);
									
									
								}

					
				});
				
				}
				}
