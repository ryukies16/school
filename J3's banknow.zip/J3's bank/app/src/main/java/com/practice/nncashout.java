package com.practice;

import android.app.*;
import android.os.*;
import android.widget.*;
import com.google.firebase.database.*;
import android.view.*;
import android.content.*;
import android.preference.*;

public class nncashout  extends Activity
	{
		
		LinearLayout nnbtn;
		TextView name,pnumber,nnbalance,nntotal,nnsend;
		FirebaseDatabase db = FirebaseDatabase.getInstance();
		DatabaseReference load = db.getReference();


		@Override
		protected void onCreate(Bundle savedInstanceState) {
				super.onCreate(savedInstanceState);
				setContentView(R.layout.nncashout);
				
				name =findViewById(R.id.nnname);
				pnumber=findViewById(R.id.nnphonenum);
				nnbalance=findViewById(R.id.nnbalance);
				nntotal=findViewById(R.id.nntotal);
				nnbtn=findViewById(R.id.nnbtn);
				nnsend=findViewById(R.id.nnsendamount);
				
				pnumber.setText(getIntent().getStringExtra("key1"));
				nntotal.setText(getIntent().getStringExtra("key2"));
				nnsend.setText(getIntent().getStringExtra("key2"));
				
				
				nnbtn.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									startActivity(new Intent(nncashout.this,DashboardActivity.class));
								}
							
					
				});
				
				}
				
				
				}
