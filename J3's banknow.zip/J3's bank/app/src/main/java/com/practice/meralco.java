package com.practice;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.content.*;
import com.google.firebase.database.*;
import java.util.*;

public class meralco extends Activity
	{ 
	FirebaseDatabase meralco = FirebaseDatabase.getInstance();
	DatabaseReference meralcos = meralco.getReference().child("Meralco Client");
	
	
	EditText macc,mname,mmount,mmail;
	Button mbtn;
		
		@Override
		protected void onCreate(Bundle savedInstanceState) {
				super.onCreate(savedInstanceState);
				setContentView(R.layout.meralco);
				
				mmail=findViewById(R.id.meralcoemail)                                                       ;
				macc=findViewById(R.id.meralcoacc);
				mname=findViewById(R.id.meralconame);
				mmount=findViewById(R.id.meralcoamount);
				mbtn=findViewById(R.id.meralcobtn);
	
				
				
				
				
				
				
				
				
				
				mbtn.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
							{
								    String maccount= macc.getText().toString();
									String mnames=mname.getText().toString();
									String amount=mmount.getText().toString();
									String memail =mmail.getText().toString();

									Intent intent = new Intent(meralco.this,nmeralco.class);
									intent.putExtra("key1",maccount);
									intent.putExtra("key2",mnames);
									intent.putExtra("key3",amount);
									intent.putExtra("key4",memail);
									startActivity(intent);
									
									HashMap<String,String> mclient = new HashMap<>();
									mclient.put("Account Number",maccount);
								    mclient.put("Account Name",mnames);
								    mclient.put("Amount",amount);
								    mclient.put("Email",memail);
									
									meralcos.setValue(mclient);
									
									

									}


							});
						
				
			   
		
				

			}
	}
