package com.practice;


import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.google.firebase.database.*;
import java.util.*;

public class converge extends Activity
	{
		FirebaseDatabase converge = FirebaseDatabase.getInstance();
		DatabaseReference converges = converge.getReference().child("Converge Client");
		
		
		EditText macc,mname,mmount,mmail;
		Button mbtn;

		@Override
		protected void onCreate(Bundle savedInstanceState) {
				super.onCreate(savedInstanceState);
				setContentView(R.layout.converge);

				mmail=findViewById(R.id.convemail)                                                       ;
				macc=findViewById(R.id.convaccnumber);
				mname=findViewById(R.id.convname);
				mmount=findViewById(R.id.convamount);
				mbtn=findViewById(R.id.convbtn);










				mbtn.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									String conaccount= macc.getText().toString();
									String connames=mname.getText().toString();
									String conamount=mmount.getText().toString();
									String conemail =mmail.getText().toString();

									Intent intent = new Intent(converge.this,nconverge.class);
									intent.putExtra("key1",conaccount);
									intent.putExtra("key2",connames);
									intent.putExtra("key3",conamount);
									intent.putExtra("key4",conemail);
									startActivity(intent);
									
									HashMap<String,String> convclient = new HashMap<>();
									convclient.put("Account Number",conaccount);
								    convclient.put("Account Name",connames);
								    convclient.put("Amount",conamount);
								    convclient.put("Email",conemail);

									converges.setValue(convclient);
									

								}


						});


			}
	}
