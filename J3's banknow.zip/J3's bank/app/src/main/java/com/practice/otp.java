package com.practice;

import android.app.*;
import android.content.*;
import android.icu.util.*;
import android.os.*;
import android.support.annotation.*;
import android.view.*;
import android.widget.*;
import com.google.android.gms.tasks.*;
import com.google.firebase.*;
import com.google.firebase.auth.*;

public class otp extends Activity
	{
		Button verify_btn;
		EditText phoneNoEnteredByTheUser;
		ProgressBar progressBar;
		
		FirebaseAuth fauth;
		PhoneAuthProvider.ForceResendingToken token;
		PhoneAuthProvider.OnVerificationStateChangedCallbacks callbacks;
		
		
		
		@Override
		protected void onCreate(Bundle savedInstanceState) {
				super.onCreate(savedInstanceState);
				setContentView(R.layout.otp);
				
			}
			}
			
