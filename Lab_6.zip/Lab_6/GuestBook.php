<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>





<h2>Enter your name to sign our guest book</h2>
<form method="POST" action="GuestBook.php">
<p>First Name <input type="text" name="first_name"
/></p>
<p>Last Name <input type="text" name="last_name"
/></p>
<p><input type="submit" value="Submit" /></p>


</form> 

<p><a href="ShowGuestBook.php">Show Guest Book</a></p>


</body>
</html>