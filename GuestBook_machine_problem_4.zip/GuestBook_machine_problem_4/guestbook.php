	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Guest Book</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<h2>Enter your name to sign our guest book</h2>
<form method="POST" action="signguestbook.php">
<p>First Name <input type="text" name="first_name" /></p>
<p>Last Name <input type="text" name="last_name" /></p>
<p><input type="submit" value="Submit" /></p>
</form>
<p><a href="showguestbook.php">Show Guest Book</a></p>
</body>
</html>
