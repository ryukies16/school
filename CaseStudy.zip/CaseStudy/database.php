<?php 

if ($errors == 0) {
$DBConnect = @mysql_connect("host", "user",
"password");
if ($DBConnect === FALSE) {
$Body .= "<p>Unable to connect to the
database " .
" server. Error code " . mysql_
errno() . ": " .
mysql_error() . "</p>\n";
++$errors;
}
else {
$DBName = "internships";
$result = @mysql_select_db($DBName,
$DBConnect);  
if ($result === FALSE) {
$Body .= "<p>Unable to select the
database. " .
"Error code " . mysql_
errno($DBConnect) .
": " . mysql_error($DBConnect)
. "</p>\n";
++$errors;
}
}
}  
 ?>